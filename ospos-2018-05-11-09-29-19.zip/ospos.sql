#
# TABLE STRUCTURE FOR: ospos_app_config
#

DROP TABLE IF EXISTS `ospos_app_config`;

CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  `branch_office_id` int(10) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`key`),
  KEY `ospos_app_config_ibfk_1` (`branch_office_id`),
  CONSTRAINT `ospos_app_config_ibfk_1` FOREIGN KEY (`branch_office_id`) REFERENCES `ospos_branch_office` (`branch_office_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('address', '123 Nowhere street', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('allow_duplicate_barcodes', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_content', 'id', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_first_row', 'category', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_font', 'Arial', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_font_size', '10', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_formats', '[]', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_generate_if_empty', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_height', '50', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_num_in_row', '2', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_page_cellspacing', '20', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_page_width', '100', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_second_row', 'item_code', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_third_row', 'unit_price', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_type', 'Code39', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('barcode_width', '250', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('cash_decimals', '2', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('cash_rounding_code', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('company', 'Open Source Point of Sale', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('company_logo', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('country_codes', 'us,es', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('currency_decimals', '2', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('currency_symbol', '$', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom10_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom1_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom2_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom3_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom4_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom5_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom6_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom7_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom8_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('custom9_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('customer_reward_enable', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('customer_sales_tax_support', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('dateformat', 'm/d/Y', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('date_or_time_format', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_origin_tax_code', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_register_mode', 'sale', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_sales_discount', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_1_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_1_rate', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_2_name', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_2_rate', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_category', 'Standard', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('default_tax_rate', '8', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('derive_sale_quantity', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('dinner_table_enable', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('email', 'changeme@example.com', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('email_receipt_check_behaviour', 'last', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('enforce_privacy', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('fax', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('financial_year', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('gcaptcha_enable', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('gcaptcha_secret_key', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('gcaptcha_site_key', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('giftcard_number', 'series', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('invoice_default_comments', 'This is a default comment', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('invoice_email_message', 'Dear {CU}, In attachment the receipt for sale {ISEQ}', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('invoice_enable', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('language', 'spanish', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('language_code', 'es', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('last_used_invoice_number', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('last_used_quote_number', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('last_used_work_order_number', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('lines_per_page', '25', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('line_sequence', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('mailpath', '/usr/sbin/sendmail', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('msg_msg', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('msg_pwd', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('msg_src', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('msg_uid', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('notify_horizontal_position', 'center', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('notify_vertical_position', 'bottom', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('number_locale', 'es-MX', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('payment_options_order', 'cashdebitcredit', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('phone', '555-555-5555', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_bottom_margin', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_delay_autoreturn', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_footer', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_header', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_left_margin', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_receipt_check_behaviour', 'last', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_right_margin', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_silently', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('print_top_margin', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('protocol', 'mail', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('quantity_decimals', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('quote_default_comments', 'This is a default quote comment', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_font_size', '12', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_show_company_name', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_show_description', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_show_serialnumber', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_show_taxes', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_show_total_discount', '1', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receipt_template', 'receipt_default', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('receiving_calculate_average_price', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('recv_invoice_format', '{CO}', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('return_policy', 'Test', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('sales_invoice_format', '{CO}', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('sales_quote_format', 'Q%y{QSEQ:6}', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_crypto', 'ssl', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_host', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_pass', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_port', '465', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_timeout', '5', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('smtp_user', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('suggestions_first_column', 'name', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('suggestions_second_column', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('suggestions_third_column', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('tax_decimals', '2', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('tax_included', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('theme', 'paper', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('thousands_separator', 'thousands_separator', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('timeformat', 'H:i:s', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('timezone', 'America/New_York', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('website', '', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('work_order_enable', '0', 1);
INSERT INTO `ospos_app_config` (`key`, `value`, `branch_office_id`) VALUES ('work_order_format', 'W%y{WSEQ:6}', 1);


#
# TABLE STRUCTURE FOR: ospos_branch_office
#

DROP TABLE IF EXISTS `ospos_branch_office`;

CREATE TABLE `ospos_branch_office` (
  `branch_office_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_office_name` varchar(50) NOT NULL,
  `deleted` int(1) DEFAULT '0',
  PRIMARY KEY (`branch_office_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (1, 'Casa Matiz', 0);
INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (2, 'Sucursal 1', 0);
INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (3, 'Sucursal 2', 0);
INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (4, 'Matizxx', 0);
INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (5, 'Matiz', 0);
INSERT INTO `ospos_branch_office` (`branch_office_id`, `branch_office_name`, `deleted`) VALUES (6, 'Sucursal Nueva', 0);


#
# TABLE STRUCTURE FOR: ospos_customers
#

DROP TABLE IF EXISTS `ospos_customers`;

CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` int(1) NOT NULL DEFAULT '1',
  `sales_tax_code` varchar(32) NOT NULL DEFAULT '1',
  `discount_percent` decimal(15,2) NOT NULL DEFAULT '0.00',
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `employee_id` int(10) NOT NULL,
  `consent` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `account_number` (`account_number`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_customers` (`person_id`, `company_name`, `account_number`, `taxable`, `sales_tax_code`, `discount_percent`, `package_id`, `points`, `deleted`, `date`, `employee_id`, `consent`) VALUES (2, '', NULL, 1, '1', '5.00', NULL, NULL, 0, '2018-05-10 23:14:51', 1, 1);


#
# TABLE STRUCTURE FOR: ospos_customers_packages
#

DROP TABLE IF EXISTS `ospos_customers_packages`;

CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES (1, 'Default', '0', 0);
INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES (2, 'Bronze', '10', 0);
INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES (3, 'Silver', '20', 0);
INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES (4, 'Gold', '30', 0);
INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES (5, 'Premium', '50', 0);


#
# TABLE STRUCTURE FOR: ospos_customers_points
#

DROP TABLE IF EXISTS `ospos_customers_points`;

CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_dinner_tables
#

DROP TABLE IF EXISTS `ospos_dinner_tables`;

CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `ospos_dinner_tables` (`dinner_table_id`, `name`, `status`, `deleted`) VALUES (1, 'Delivery', 0, 0);
INSERT INTO `ospos_dinner_tables` (`dinner_table_id`, `name`, `status`, `deleted`) VALUES (2, 'Take Away', 0, 0);


#
# TABLE STRUCTURE FOR: ospos_employees
#

DROP TABLE IF EXISTS `ospos_employees`;

CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `hash_version` int(1) NOT NULL DEFAULT '2',
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  `branch_office_admin` int(1) DEFAULT '0',
  `branch_office_id` int(11) NOT NULL,
  UNIQUE KEY `username` (`username`),
  KEY `person_id` (`person_id`),
  KEY `ospos_employees_ibfk_2` (`branch_office_id`),
  CONSTRAINT `ospos_employees_ibfk_2` FOREIGN KEY (`branch_office_id`) REFERENCES `ospos_branch_office` (`branch_office_id`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_employees` (`username`, `password`, `person_id`, `deleted`, `hash_version`, `language`, `language_code`, `branch_office_admin`, `branch_office_id`) VALUES ('admin', '$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG', 1, 0, 2, '', '', 1, 1);
INSERT INTO `ospos_employees` (`username`, `password`, `person_id`, `deleted`, `hash_version`, `language`, `language_code`, `branch_office_admin`, `branch_office_id`) VALUES ('jhp301', '$2y$10$ORkir7OlNZYLC/DzrDI6fuNQ3eJddq3cLHKqz5DaWD3kOlq1eWHce', 8, 0, 2, 'english', 'en-US', 1, 1);
INSERT INTO `ospos_employees` (`username`, `password`, `person_id`, `deleted`, `hash_version`, `language`, `language_code`, `branch_office_admin`, `branch_office_id`) VALUES ('jpacheco', '$2y$10$3VkbqJhqdoLztZUE40ETIuljsksNitskbeDOX3ApQgPEuVCV91Fd.', 6, 0, 2, 'spanish', 'es', 0, 1);
INSERT INTO `ospos_employees` (`username`, `password`, `person_id`, `deleted`, `hash_version`, `language`, `language_code`, `branch_office_admin`, `branch_office_id`) VALUES ('Uno12', '$2y$10$VhANhWKulRo.Ch42aDYVnu2R/LSu6Z8BnG.48it0RHAlguNDB88G6', 12, 0, 2, 'english', 'en-US', 1, 1);


#
# TABLE STRUCTURE FOR: ospos_expense_categories
#

DROP TABLE IF EXISTS `ospos_expense_categories`;

CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_expenses
#

DROP TABLE IF EXISTS `ospos_expenses`;

CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `supplier_name` varchar(255) DEFAULT NULL,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_giftcards
#

DROP TABLE IF EXISTS `ospos_giftcards`;

CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_grants
#

DROP TABLE IF EXISTS `ospos_grants`;

CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('branch_managers', 1, 'office');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('branch_office', 1, 'office');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('config', 1, 'office');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('customers', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('customers', 6, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('customers', 8, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('customers', 12, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('employees', 1, 'office');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('expenses', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('expenses_categories', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('giftcards', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('home', 1, 'office');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('home', 6, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('home', 8, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('home', 12, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('items', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('items', 6, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('items_stock', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('items_stock', 6, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('item_kits', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('messages', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('office', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('receivings', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('receivings_stock', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_categories', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_customers', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_discounts', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_employees', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_expenses_categories', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_inventory', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_items', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_payments', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_receivings', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_sales', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_suppliers', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('reports_taxes', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('sales', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('sales_delete', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('sales_stock', 1, '--');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('suppliers', 1, 'home');
INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES ('taxes', 1, 'office');


#
# TABLE STRUCTURE FOR: ospos_inventory
#

DROP TABLE IF EXISTS `ospos_inventory`;

CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT '0',
  `trans_user` int(11) NOT NULL DEFAULT '0',
  `trans_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_item_kit_items
#

DROP TABLE IF EXISTS `ospos_item_kit_items`;

CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_item_kits
#

DROP TABLE IF EXISTS `ospos_item_kits`;

CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT '0',
  `kit_discount_percent` decimal(15,2) NOT NULL DEFAULT '0.00',
  `price_option` tinyint(2) NOT NULL DEFAULT '0',
  `print_option` tinyint(2) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`item_kit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_item_quantities
#

DROP TABLE IF EXISTS `ospos_item_quantities`;

CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_items
#

DROP TABLE IF EXISTS `ospos_items`;

CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT '0.000',
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT '1.000',
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `stock_type` tinyint(2) NOT NULL DEFAULT '0',
  `item_type` tinyint(2) NOT NULL DEFAULT '0',
  `tax_category_id` int(10) NOT NULL DEFAULT '1',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `custom1` varchar(255) DEFAULT NULL,
  `custom2` varchar(255) DEFAULT NULL,
  `custom3` varchar(255) DEFAULT NULL,
  `custom4` varchar(255) DEFAULT NULL,
  `custom5` varchar(255) DEFAULT NULL,
  `custom6` varchar(255) DEFAULT NULL,
  `custom7` varchar(255) DEFAULT NULL,
  `custom8` varchar(255) DEFAULT NULL,
  `custom9` varchar(255) DEFAULT NULL,
  `custom10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `item_number` (`item_number`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_items_taxes
#

DROP TABLE IF EXISTS `ospos_items_taxes`;

CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_migrations
#

DROP TABLE IF EXISTS `ospos_migrations`;

CREATE TABLE `ospos_migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_migrations` (`version`) VALUES ('20180501100000');


#
# TABLE STRUCTURE FOR: ospos_modules
#

DROP TABLE IF EXISTS `ospos_modules`;

CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_branch_managers', 'module_branch_managers_desc', 82, 'branch_managers');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_branch_office', 'module_branch_office_desc', 81, 'branch_office');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_config', 'module_config_desc', 110, 'config');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_customers', 'module_customers_desc', 10, 'customers');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_employees', 'module_employees_desc', 80, 'employees');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_expenses', 'module_expenses_desc', 108, 'expenses');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_expenses_categories', 'module_expenses_categories_desc', 109, 'expenses_categories');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_giftcards', 'module_giftcards_desc', 90, 'giftcards');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_home', 'module_home_desc', 1, 'home');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_items', 'module_items_desc', 20, 'items');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_item_kits', 'module_item_kits_desc', 30, 'item_kits');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_messages', 'module_messages_desc', 98, 'messages');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_office', 'module_office_desc', 999, 'office');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_receivings', 'module_receivings_desc', 60, 'receivings');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_reports', 'module_reports_desc', 50, 'reports');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_sales', 'module_sales_desc', 70, 'sales');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_suppliers', 'module_suppliers_desc', 40, 'suppliers');
INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES ('module_taxes', 'module_taxes_desc', 105, 'taxes');


#
# TABLE STRUCTURE FOR: ospos_people
#

DROP TABLE IF EXISTS `ospos_people`;

CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Johnxx', 'Doe', 1, '554-554-6583', 'changeme@example.com', 'Address 1', '', '', '', '', '', '', 1);
INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Bob', 'Smith', 1, '585-555-1111', 'bsmith@nowhere.com', '123 Nowhere Street', 'Apt 4', 'Awesome', 'NY', '11111', 'USA', 'Awesome guy', 2);
INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Jhonatan', 'Pacheco', 1, '015545546583', 'jhonatanpachecohernandez@gmail.com', '2da de Aguacate S/N', '2da de Aguacate S/N', 'El Rosario', '', '42672', 'México', '', 6);
INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Raciel', 'Pacheco', NULL, '015535536583', '', '2da de Aguacate S/N', '2da de Aguacate S/N', 'El Rosario', '', '42672', 'México', '', 8);
INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Raciel', 'Pacheco', NULL, '015545546583', 'jhonatanpachecohernandez@gmail.com', '2da de Aguacate S/N', '2da de Aguacate S/N', 'El Rosario', '', '42672', 'México', '', 10);
INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES ('Uno', 'Dos', 1, '', '', '', '', '', '', '', '', '', 12);


#
# TABLE STRUCTURE FOR: ospos_permissions
#

DROP TABLE IF EXISTS `ospos_permissions`;

CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('branch_managers', 'branch_managers', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('branch_office', 'branch_office', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('config', 'config', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('customers', 'customers', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('employees', 'employees', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('expenses', 'expenses', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('expenses_categories', 'expenses_categories', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('giftcards', 'giftcards', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('home', 'home', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('items', 'items', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('items_stock', 'items', 1);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('item_kits', 'item_kits', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('messages', 'messages', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('office', 'office', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('receivings', 'receivings', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('receivings_stock', 'receivings', 1);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_categories', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_customers', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_discounts', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_employees', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_expenses_categories', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_inventory', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_items', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_payments', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_receivings', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_sales', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_suppliers', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('reports_taxes', 'reports', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('sales', 'sales', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('sales_delete', 'sales', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('sales_stock', 'sales', 1);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('suppliers', 'suppliers', NULL);
INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES ('taxes', 'taxes', NULL);


#
# TABLE STRUCTURE FOR: ospos_receivings
#

DROP TABLE IF EXISTS `ospos_receivings`;

CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT '0',
  `comment` text,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_receivings_items
#

DROP TABLE IF EXISTS `ospos_receivings_items`;

CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT '0',
  `item_id` int(10) NOT NULL DEFAULT '0',
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT '0.000',
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount_percent` decimal(15,2) NOT NULL DEFAULT '0.00',
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT '1.000',
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales
#

DROP TABLE IF EXISTS `ospos_sales`;

CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT '0',
  `comment` text,
  `invoice_number` varchar(32) DEFAULT NULL,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `sale_status` tinyint(2) NOT NULL DEFAULT '0',
  `dinner_table_id` int(11) DEFAULT NULL,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales_items
#

DROP TABLE IF EXISTS `ospos_sales_items`;

CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT '0',
  `item_id` int(10) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT '0',
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT '0.000',
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount_percent` decimal(15,2) NOT NULL DEFAULT '0.00',
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales_items_taxes
#

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;

CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax_type` tinyint(2) NOT NULL DEFAULT '0',
  `rounding_code` tinyint(2) NOT NULL DEFAULT '0',
  `cascade_tax` tinyint(2) NOT NULL DEFAULT '0',
  `cascade_sequence` tinyint(2) NOT NULL DEFAULT '0',
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales_items` (`sale_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales_payments
#

DROP TABLE IF EXISTS `ospos_sales_payments`;

CREATE TABLE `ospos_sales_payments` (
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`sale_id`,`payment_type`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales_reward_points
#

DROP TABLE IF EXISTS `ospos_sales_reward_points`;

CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sales_taxes
#

DROP TABLE IF EXISTS `ospos_sales_taxes`;

CREATE TABLE `ospos_sales_taxes` (
  `sale_id` int(10) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(2) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code` varchar(32) NOT NULL DEFAULT '',
  `rounding_code` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sale_id`,`tax_type`,`tax_group`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_type`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_sessions
#

DROP TABLE IF EXISTS `ospos_sessions`;

CREATE TABLE `ospos_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('opg7htp1cvbutvdckcgnpirhvuoh0kmn', '::1', 1525992182, '__ci_last_regenerate|i:1525991854;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pjdgp90gair9kje2chhahh9qs810ei2i', '::1', 1525992447, '__ci_last_regenerate|i:1525992222;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4lohf0mf1a9cfpo879ejq2iqfq71o8op', '::1', 1525992827, '__ci_last_regenerate|i:1525992547;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dkh0bni8g7ojefpq8rn9kude98qoptr0', '::1', 1525993112, '__ci_last_regenerate|i:1525992941;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cvvg1hvp05vf9rnk3mp83992jhkj2ksp', '::1', 1525993691, '__ci_last_regenerate|i:1525993421;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bhc6icqchivvk1q5iihclovjsth9hskr', '::1', 1525993970, '__ci_last_regenerate|i:1525993727;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bc88qr4s2i6td90vl2nkdc522ohjs5l7', '::1', 1525994309, '__ci_last_regenerate|i:1525994028;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mr3gqa91hlvnl9qu07k7ksngcegrlde1', '::1', 1525994633, '__ci_last_regenerate|i:1525994356;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rk69ftk21g5np3a0rh6ehv9ufvoav32j', '::1', 1525994824, '__ci_last_regenerate|i:1525994803;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('til402avn2gr1iel9v32drdqdvcauehr', '::1', 1525995150, '__ci_last_regenerate|i:1525995149;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36cq86va948fqqiph75v5enofodpf6uk', '::1', 1525995517, '__ci_last_regenerate|i:1525995516;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tqt8v7k6ejofmv7hl0ofpda8lb7vnqmg', '::1', 1525997749, '__ci_last_regenerate|i:1525997471;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oa3b84g7k9224gjc44rg258gtf1eavb0', '::1', 1525998145, '__ci_last_regenerate|i:1525997789;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r6tcln9486ce3hcp61pfbvepjufdim1c', '::1', 1525998797, '__ci_last_regenerate|i:1525998549;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ui238rd6qrgsv4qbt8n8jvcifhr3qcpn', '::1', 1525999133, '__ci_last_regenerate|i:1525998852;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qn12f20kvftiu1n5u4dgaura1kprk7v5', '::1', 1525999918, '__ci_last_regenerate|i:1525999794;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lolp196vmp2l2si576veebe8mpgkab9r', '::1', 1526001405, '__ci_last_regenerate|i:1526001172;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pcoqdk9mrlj43aqbbc6jkhsb71b7e1jn', '::1', 1526001586, '__ci_last_regenerate|i:1526001544;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tg61aeuvdpsr8qhtoffpij1ogu1avvsk', '::1', 1526002075, '__ci_last_regenerate|i:1526002059;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lqnrgat1ot1v15da65672d9qdgje0f8v', '::1', 1526002843, '__ci_last_regenerate|i:1526002569;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0c1tln9atrkf9ji67ih0oqml4nc4kbqf', '::1', 1526003190, '__ci_last_regenerate|i:1526002892;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6g4hnfput1g2isrnjs6lsn28lidnfl20', '::1', 1526003494, '__ci_last_regenerate|i:1526003273;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2rassn9vr9515n34ckcrtuoqtp4albrq', '::1', 1526004311, '__ci_last_regenerate|i:1526004309;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vn29k80kg12h0jgud57cdm6o4dseq5jb', '::1', 1526004704, '__ci_last_regenerate|i:1526004704;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5kub8naq9302atlqlc5jbuhd1rkphq8', '::1', 1526005864, '__ci_last_regenerate|i:1526005823;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ads2ab3aq1arq134gmqlllokk08culh', '::1', 1526007061, '__ci_last_regenerate|i:1526006132;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a10gl29tb93q71be2qud8752osb7dm4c', '::1', 1526007440, '__ci_last_regenerate|i:1526007374;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nho0u6k956u39r16ta45fflm923meumj', '::1', 1526007955, '__ci_last_regenerate|i:1526007953;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qse5fp3cs4vevp5mm6j9scheagfb979b', '::1', 1526008738, '__ci_last_regenerate|i:1526008448;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gdl2dqa1eh0iru7tca1ck9h1vn6n3jpf', '::1', 1526009866, '__ci_last_regenerate|i:1526009865;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k0pb4a0of5tknf1jb89k7934piss151t', '::1', 1526011609, '__ci_last_regenerate|i:1526011607;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ljnsj41hnt0absem3fm9jrs1t7kqrvuh', '::1', 1526012718, '__ci_last_regenerate|i:1526012512;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bo9t5d2s8rt521ku09p7b4ddp753437v', '::1', 1526013321, '__ci_last_regenerate|i:1526013029;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0upb10p6dm7gdne0d5lugevje154qspb', '::1', 1526013581, '__ci_last_regenerate|i:1526013362;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3kovgg5tdpuqncapnpam58hu0f1inffd', '::1', 1526013953, '__ci_last_regenerate|i:1526013736;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bhoaj38vlgbg2s6o3cjp1ldlallb0sn5', '::1', 1526014255, '__ci_last_regenerate|i:1526014113;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jjo5ik92sqmt24siouq7r81vlq4pckcv', '::1', 1526014776, '__ci_last_regenerate|i:1526014741;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qcturma4kppl70fuktnietkod4ev95oo', '::1', 1526015326, '__ci_last_regenerate|i:1526015092;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rfdq6f2gfu4pouu8rp22qq3ua6s74841', '::1', 1526015724, '__ci_last_regenerate|i:1526015466;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f6bh1rbvc8qgc1s2oajtcpphq3uvip2c', '::1', 1526015792, '__ci_last_regenerate|i:1526015775;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otur07sobo5ri1mhl0ufu3gc6kessqmk', '::1', 1526042912, '__ci_last_regenerate|i:1526042626;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('un3u90s3iup03ne7022nnvsvuacmf475', '::1', 1526043110, '__ci_last_regenerate|i:1526042956;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5b5et6asuuqjmrgli749nae1uil1dd4', '::1', 1526043301, '__ci_last_regenerate|i:1526043295;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jus55l2acjubd7pcjdtsojnrpivo15cu', '::1', 1526043819, '__ci_last_regenerate|i:1526043678;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6j7obt24kglge9jpqha168k2mj8pmiaf', '::1', 1526044089, '__ci_last_regenerate|i:1526044012;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('auemaofqht984o93sfh7k32253jvvsbo', '::1', 1526045056, '__ci_last_regenerate|i:1526044646;person_id|s:1:\"1\";menu_group|s:6:\"office\";');
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7vi2s9h2i31t95envu3okm666sitna38', '::1', 1526045349, '__ci_last_regenerate|i:1526045203;person_id|s:1:\"1\";menu_group|s:6:\"office\";');


#
# TABLE STRUCTURE FOR: ospos_stock_locations
#

DROP TABLE IF EXISTS `ospos_stock_locations`;

CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ospos_stock_locations` (`location_id`, `location_name`, `deleted`) VALUES (1, 'stock', 0);


#
# TABLE STRUCTURE FOR: ospos_suppliers
#

DROP TABLE IF EXISTS `ospos_suppliers`;

CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `account_number` (`account_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_tax_categories
#

DROP TABLE IF EXISTS `ospos_tax_categories`;

CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(2) NOT NULL,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ospos_tax_categories` (`tax_category_id`, `tax_category`, `tax_group_sequence`) VALUES (1, 'Standard', 10);
INSERT INTO `ospos_tax_categories` (`tax_category_id`, `tax_category`, `tax_group_sequence`) VALUES (2, 'Service', 12);
INSERT INTO `ospos_tax_categories` (`tax_category_id`, `tax_category`, `tax_group_sequence`) VALUES (3, 'Alcohol', 11);


#
# TABLE STRUCTURE FOR: ospos_tax_code_rates
#

DROP TABLE IF EXISTS `ospos_tax_code_rates`;

CREATE TABLE `ospos_tax_code_rates` (
  `rate_tax_code` varchar(32) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `rounding_code` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_tax_code`,`rate_tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ospos_tax_codes
#

DROP TABLE IF EXISTS `ospos_tax_codes`;

CREATE TABLE `ospos_tax_codes` (
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `tax_code_type` tinyint(2) NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

